window.onload = function(){
	languageChange();
}

//detecting language
function detectLanguage() {

	var language = navigator.language;
	//document.getElementById("demo").innerHTML = language;
	return language;
}

var languageSelector;

function formFinalURL(){    
	var tempUrl;
	var googleTranslateURL = "https://translate.google.com/translate?sl=auto&tl=(%translateTo%)&u=";
	var gotoUrl;
	languageSelector = document.getElementById("selectLanguage").value;

	var arabic = "ar";
	var english = "en";
	var hindi = "hi";
	var german = "de";
	var french = "fr";
	
	//appending to the URL according to choice of tne user
	switch(languageSelector){

	case "Arabic":

		gotoUrl = googleTranslateURL.replace("(%translateTo%)", arabic);
		break;

	case "English":

		gotoUrl = googleTranslateURL.replace("(%translateTo%)", english);
		break;

	case "Hindi":

		gotoUrl = googleTranslateURL.replace("(%translateTo%)", hindi);
		break;

	case "French":

		gotoUrl = googleTranslateURL.replace("(%translateTo%)", french);
		break;

	case "German":

		gotoUrl = googleTranslateURL.replace("(%translateTo%)", german);
		break;
	}
	
		chrome.tabs.query({'active': true, 'currentWindow': true}, function (tabs) {
		tempUrl =  new URL(tabs[0].url);
		if(tempUrl.hostname == "translate.google.com"){
			chrome.tabs.executeScript(null,{"code": "window.history.back()"});
					chrome.tabs.query({'active': true, 'currentWindow': true}, function (tabs) {
		var tempUrl0 =  new URL(tabs[0].url);
				//forming final url to redirect to google translate services
		gotoUrl = gotoUrl + encodeURIComponent(tempUrl0);
		//redirecting to google translate
		chrome.tabs.update({url: gotoUrl});
	});
		}else{
		//forming final url to redirect to google translate services
		gotoUrl = gotoUrl + encodeURIComponent(tempUrl);
		//redirecting to google translate
		chrome.tabs.update({url: gotoUrl});
		}
	});

}

//to create a dropdown for language selection
function languageChange(){

//display current language
	document.getElementById("currentLanguage").innerHTML = "Current Language is "+detectLanguage();

	var myArray = new Array("English", "Hindi", "Arabic","French","German");
//	Get dropdown element from DOM
	var dropdown = document.getElementById("selectLanguage");

//	Loop through the array
	for (var i = 0; i < myArray.length; ++i) {
		// Append the element to the end of Array list
		dropdown[dropdown.length] = new Option(myArray[i], myArray[i]);
	} 

	var button = document.createElement("input");
	button.setAttribute('type', 'submit');
	button.setAttribute('ID', 'Translate');
	button.setAttribute('value', 'Translate');
	button.onclick = function(){ 
		formFinalURL()
	};
	document.body.appendChild(button);
}